#include "NodeInternal.h"

void AENodeMaterialDelete(AENode* node){
	AENodeMaterial* material=(AENodeMaterial*)node;
	for(int i=0;i<material->texUnitCount;i++){
		AETextureDelete(material->textures[i]);
		free(material->textureNames[i]);
	}
	free(material->textures);
	free(material->textureUniforms);
	free(material->textureNames);
	glDeleteShader(material->fshader);
	glDeleteShader(material->vshader);
	glDeleteShader(material->program);
}

static unsigned int AEShaderTextureUnitCount=0;

bool AEShadersEnabled=false;

void AENodeMaterialRender(AENode* node){
	AENodeMaterial* material=(AENodeMaterial*)node;
	/*static void* lastBound=NULL;
	if(lastBound!=node){
		printf("%s(): %i\n",__func__,__LINE__);
		lastBound=node;
	}*/
	if(material==NULL){
		if(AEShadersEnabled==0) for(unsigned char i=AEShaderTextureUnitCount;i--;){
			glActiveTexture(GL_TEXTURE0+i);
			AETextureBind(0);
		}
		AEShaderTextureUnitCount=0;
		if(AEShadersEnabled) glUseProgram(0);
		AEError("Binding NULL material\n");
		return;
	}
	
	if(AEShadersEnabled){
		glUseProgram(material->program);
		if(material->timeUniform) glUniform1f((GLint)material->timeUniform-1,AENodesTime*0.001);
	}
	//It's designed this way so that the last unit accessed is 0, so I have one less state to change
	for(unsigned char i = material->texUnitCount; i--; /*Intentionally nothing here*/){
		glActiveTexture(GL_TEXTURE0+i);
		AETextureBind(material->textures[i]);
		if(AEShadersEnabled && material->textureUniforms) glUniform1i((GLint)material->textureUniforms[i]-1,i);
	}
	//printf("Binding %s\n",AENodeTypesGet(AENodeTypeGet(node))->name);
	AEShaderTextureUnitCount=material->texUnitCount;
}

/*void AENodeMaterialStep(AENode* node,float stepInSeconds){
	if(AEShadersEnabled==false) return;
	
	AENodeMaterial* material=(AENodeMaterial*)node;
	
	//material->time+=stepInSeconds;
}*/

void AENodeMaterialShaderSet(AENode* node,char* vshadertext,char* fshadertext){
	if(AEShadersEnabled==false) return;
	
	AENodeMaterial* material=(AENodeMaterial*)node;
	
	if(vshadertext){
		if(material->vshader){
			glDeleteShader(material->vshader);
			material->vshader=0;
		}
		material->vshader=glCreateShader(GL_VERTEX_SHADER);
		glShaderSource(material->vshader, 1, (const GLchar**)&vshadertext,NULL);
		glCompileShader(material->vshader);
		
		//Make it easier for copy/paste
		GLuint object=material->vshader;
		char* shadertext=vshadertext;
		char* shadertype="Vertex";
		
		GLint status=0;
		glGetShaderiv(object,GL_COMPILE_STATUS,&status);
		if(status==0){
			GLint maxlength=0;
			glGetShaderiv(object,GL_INFO_LOG_LENGTH,&maxlength);
			GLint actuallength=0;
			char* log=malloc(maxlength+1);
			glGetShaderInfoLog(object,maxlength,&actuallength,log);
			fprintf(stderr,"%s Shader Error: %s\n\n\n\n With shader:\n%s\n",shadertype,log,shadertext);
			free(log);
		}
	}
	
	if(fshadertext){
		if(material->vshader){
			glDeleteShader(material->fshader);
			material->fshader=0;
		}
		material->fshader=glCreateShader(GL_VERTEX_SHADER);
		glShaderSource(material->fshader, 1, (const GLchar**)&fshadertext,NULL);
		glCompileShader(material->fshader);
		
		//Make it easier for copy/paste
		GLuint object=material->fshader;
		char* shadertext=fshadertext;
		char* shadertype="Fragment";
		
		GLint status=0;
		glGetShaderiv(object,GL_COMPILE_STATUS,&status);
		if(status==0){
			GLint maxlength=0;
			glGetShaderiv(object,GL_INFO_LOG_LENGTH,&maxlength);
			GLint actuallength=0;
			char* log=malloc(maxlength+1);
			glGetShaderInfoLog(object,maxlength,&actuallength,log);
			fprintf(stderr,"%s Shader Error: %s\n\n\n\n With shader:\n%s\n",shadertype,log,shadertext);
			free(log);
		}
	}
	
	if(vshadertext==NULL && fshadertext==NULL){
		if(material->program){
			glDeleteProgram(material->program);
			material->program=0;
		}
		material->program=glCreateProgram();
		if(material->fshader) glAttachShader(material->program,material->fshader);
		if(material->vshader) glAttachShader(material->program,material->vshader);
		glLinkProgram(material->program);
		
		//Make it easier for copy/paste
		GLuint object=material->program;
		char* shadertext=NULL;
		char* shadertype="Program";
		
		GLint status=0;
		glGetProgramiv(object,GL_LINK_STATUS,&status);
		if(status==0){
			GLint maxlength=0;
			glGetProgramiv(object,GL_INFO_LOG_LENGTH,&maxlength);
			GLint actuallength=0;
			char* log=malloc(maxlength+1);
			glGetProgramInfoLog(object,maxlength,&actuallength,log);
			fprintf(stderr,"%s Shader Error: %s\n\n\n\n With shader:\n%s\n",shadertype,log,shadertext);
			free(log);
		}
	}
	
	free(material->textureUniforms);
	material->textureUniforms=NULL;
	
	if(material->texUnitCount)
		material->textureUniforms=calloc(1,material->texUnitCount*sizeof(GLint));
	for(unsigned char i=material->texUnitCount;i--;){
		material->textureUniforms[i]=glGetUniformLocation(material->program,material->textureNames[i])+1;
		printf("Texture %i: %i\n",(int)i,(int)material->textureUniforms[i]);
	}
	
	material->timeUniform=glGetUniformLocation(material->program,"time")+1;
	printf("Time: %i\n",(int)material->timeUniform);
}

void AENodeMaterialTextureSet(AENode* node,char* name,AEImage* image){
	AENodeMaterial* material=(AENodeMaterial*)node;
	material->texUnitCount++;
	material->textures=realloc(material->textures,material->texUnitCount*sizeof(AETexture));
	material->textureNames=realloc(material->textureNames,material->texUnitCount*sizeof(char*));
	material->textureNames[material->texUnitCount-1]=strdup(name);
	material->textures[material->texUnitCount-1]=AEImageToTexture(image);
	AEImageDelete(image);
}