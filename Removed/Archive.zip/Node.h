#pragma once

#include "Core.h"
#include "Math3D.h"
#include "VBO.h"
#include "List.h"
#include "Image.h"
#include "Table.h"

struct AENode;
typedef struct AENode AENode;

struct AENodeType;
typedef struct AENodeType AENodeType;

enum{
	AENodeTypeUnknown,
	AENodeTypeEnt,
	AENodeTypeMesh,
	AENodeTypeMaterial,
	AENodeTypeLastPredefined=AENodeTypeMaterial
	//,AENodeTypeWorld
};

void AENodesInit(void);
void AENodesQuit(void);
//Ideally, xxxStep should be called with constant stepsize
//Also does additional work that is hidden
void AENodesStep(float stepInSeconds);
void AENodesRender(void);
void AENodeRootSet(AENode* node);
AENode* AENodeRootGet(void);

//AENode* AENodeNew(unsigned int type,char* name);
AENode* AENodeClone(AENode* node);
AENode* AENodeRetain(AENode* node);
void AENodeDelete(AENode* node);
void AENodeRender(AENode* node);
void AENodeStep(AENode* node,float stepInSeconds);

typedef void* (*AENodeMessageFunc)(AENode* node,...);
AENodeMessageFunc AENodeMessageGet(AENode* node);

size_t AENodeSizeGet(AENode* node);
AENode* AENodeSizeAppend(AENode* node,void* bytes,size_t size);

char* AENodeNameGet(AENode* node);
void AENodeNameSet(AENode* node,char* name);

void* AENodeAuxGet(AENode* node);
void AENodeAuxSet(AENode* node,void* data);

//Ent Specific, may also apply to others

//typedef void (*AENodeEntMessageFunc)(AENode* node,char* message,void* res,...);
//void AENodeEntMessagesAdd(AENode* node,char* name,void* messsage);
//void* AENodeEntMessagesLookup(AENode* node,char* name);

void AENodeEntPositionGet(AENode* node,AEVec3* v3);
void AENodeEntPositionSet(AENode* node,float x,float y,float z);
void AENodeEntVelocityGet(AENode* node,AEVec3* v3);
void AENodeEntVelocitySet(AENode* node,float x,float y,float z);

//Radial (Rotational) versions, obviously these have more correct names, just that this is more consistent
void AENodeEntRotationGet(AENode* node,AEVec3* v3);
void AENodeEntRotationSet(AENode* node,float x,float y,float z);
void AENodeEntRotationGetQuaterion(AENode* node,AEQuat* q4);
void AENodeEntRotationSetQuaterion(AENode* node,float x,float y,float z,float w);
void AENodeEntSpinGet(AENode* node,AEVec3* v3);
void AENodeEntSpinSet(AENode* node,float x,float y,float z);

//Bounding sphere for occlusion culling
float AENodeEntRadiusGet(AENode* node);
void AENodeEntRadiusSet(AENode* node,float radius);

void AENodeEntAddChild(AENode* node,AENode* node2);
size_t AENodeEntChildCount(AENode* node);
AENode* AENodeEntGetChild(AENode* node,size_t i);
AENode* AENodeEntFindChild(AENode* node,char* name);
void AENodeEntRemoveChild(AENode* node,AENode* node2);


//Render children are rendered within the ent's transform
void AENodeEntAddRenderChild(AENode* node,AENode* node2);
size_t AENodeEntRenderChildCount(AENode* node);
AENode* AENodeEntGetRenderChild(AENode* node,size_t i);
AENode* AENodeEntFindRenderChild(AENode* node,char* name);
void AENodeEntRemoveRenderChild(AENode* node,AENode* node2);

#define AENodeEntOptimizationMarkStatic 1
#define AENodeEntOptimizationFlattenSimilarStaticChildren 2
//#define AENodeEntOptimization 3

//Untold horrors will happen for those who pass in that which is not an entity
void* AENodeEntOptimize(AENode* node,unsigned int optimization,float* params);

//Mesh Specific

//Material Specific
void AENodeMaterialShaderSet(AENode* node,char* vshader,char* fshader);
void AENodeMaterialTextureSet(AENode* node,char* name,AEImage* image);
extern bool AEShadersEnabled;

///Deprecated
void AENodeMeshVBOSet(AENode* node,AEVBO* vbo);
AEVBO* AENodeMeshVBOGet(AENode* node);